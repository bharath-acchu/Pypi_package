from setuptools import setup

setup(name='bigbharath_probability',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['bigbharath_probability'],
      author = 'Bharath C S',
      author_email ='bharath.sdupuc@gmail.com',
      zip_safe=False)